----------imd2mc v1.1 by Ramsey45----------

--[[
    使用方法：
    1.将待转换imd文件放入谱面所在文件夹,并重命名为'谱面文件名'+'_resource.imd'
      例如,谱面文件名为'123456789.mc',则imd文件命名为'123456789.mc_resource.imd'
    2.编辑器内点击插件,输入要生成的谱面key数（可以大于原imd谱面key数）
    3.修改编辑器内bpm，使其与imd谱面bpm一致；同时修改编辑器内offset
    4.滚动编辑器面板使红线对齐要放置的第一个note位置
    5.再次点击插件
    6.再次点击插件,完成生成
]]

PluginName = 'imd_2_mc'
PluginMode = 7
PluginType = 0
PluginRequire = '6.0.40'

bpm = 120
column = 4
flag = 1
startbeat = nil
firstnotetime = 0
zerobeat = {beat = 0, numor = 0, denom = 1}


function Run()
    local data = Editor:ReadBytes("resource.imd")
    if data == nil then
        Editor:ShowMessage('缺少待转换imd文件')
        return
    end
    local bytenum = 0
    for k, v in pairs(data) do
        bytenum = bytenum + 1
    end
    
    if flag == 1 then
        Editor:GetUserInput("请输入key数(4/5/6，可以大于原谱key数)", '4/5/6', function (text)
            column = tonumber(text)
            Editor:ShowMessage(column..'k selected\n请滚动至合适的beat位置，下次点击将选择该位置作为第一个note位置')
        end)
        flag = 2
        return
    end
    if flag == 2 then
        startbeat = Editor:GetCurrentBeat()
        Editor:ShowMessage("已选择当前beat为第一个note位置，再次点击生成")
        flag = 3
        return
    end

    --删除原有note，后续config接口出来后可做成可选项
    local notecount = Editor:GetNoteCount()
    local notes = {}
    for i=0, notecount-1 do
        table.insert(notes, Editor:GetNoteAt(i))
    end
    for k, v in pairs(notes) do
        Editor:DeleteNote(v)
    end

    local note = nil
    local noteflag = 0
    local lastbody = 0
    local sumbodytime = 0
    local sumflickcolumn = 0

    local beatcount = string.unpack('<i4', string.pack("BBBB", data[4], data[5], data[6], data[7]))
    bpm = string.unpack('<d', string.pack("BBBBBBBB", data[12], data[13], data[14], data[15], data[16], data[17], data[18], data[19]))
    local i = 14 + 12 * beatcount
    while(i < bytenum) 
    do
        if data[i] >> 4 == 0x6 then
            if i == 14 + 12 * beatcount then
                firstnotetime = string.unpack('<i4', string.pack("BBBB", data[i + 2], data[i + 3], data[i + 4], data[i + 5]))
            end
            note = Editor:AddNote(2048)
            Editor:SetNoteBeat(note, _beat(string.unpack('<i4', string.pack("BBBB", data[i + 2], data[i + 3], data[i + 4], data[i + 5]))), 1)
            Editor:SetNoteX(note, _x(data[i + 6]))
            Editor:SetNoteWidth(note, _width(0))
            if data[i] & 0x0F == 0x01 then
                Editor:AddNoteSlideBody(note, zerobeat)
                Editor:SetNoteSlideBodyX(note, 0, string.unpack('<i4', string.pack("BBBB", data[i + 7], data[i + 8], data[i + 9], data[i + 10])) * (_x(1) - _x(0)))
                lastbody = 0
                sumbodytime = 0
                sumflickcolumn = string.unpack('<i4', string.pack("BBBB", data[i + 7], data[i + 8], data[i + 9], data[i + 10]))
            else
                Editor:AddNoteSlideBody(note, _slidebodybeat(string.unpack('<i4', string.pack("BBBB", data[i + 7], data[i + 8], data[i + 9], data[i + 10]))))
                Editor:SetNoteSlideBodyX(note, 0, 0)
                lastbody = 0
                sumbodytime = string.unpack('<i4', string.pack("BBBB", data[i + 7], data[i + 8], data[i + 9], data[i + 10]))
                sumflickcolumn = 0
            end
            i = i + 11
        elseif data[i] >> 4 == 0x2 then
            if data[i] & 0x0F == 0x01 then
                sumflickcolumn = sumflickcolumn + string.unpack('<i4', string.pack("BBBB", data[i + 7], data[i + 8], data[i + 9], data[i + 10]))
                Editor:SetNoteSlideBodyX(note, lastbody, sumflickcolumn * (_x(1) - _x(0)))
            else
                sumbodytime = sumbodytime + string.unpack('<i4', string.pack("BBBB", data[i + 7], data[i + 8], data[i + 9], data[i + 10]))
                Editor:AddNoteSlideBody(note, _slidebodybeat(sumbodytime))
                Editor:SetNoteSlideBodyX(note, lastbody + 1, Editor:GetNoteSlideBodyX(note, lastbody))
                lastbody = lastbody + 1
            end
            i = i + 11
        elseif data[i] >> 4 == 0xA then
            if data[i] & 0x0F == 0x01 then
                sumflickcolumn = sumflickcolumn + string.unpack('<i4', string.pack("BBBB", data[i + 7], data[i + 8], data[i + 9], data[i + 10]))
                Editor:SetNoteSlideBodyX(note, lastbody, sumflickcolumn * (_x(1) - _x(0)))
            else
                sumbodytime = sumbodytime + string.unpack('<i4', string.pack("BBBB", data[i + 7], data[i + 8], data[i + 9], data[i + 10]))
                Editor:AddNoteSlideBody(note, _slidebodybeat(sumbodytime))
                Editor:SetNoteSlideBodyX(note, lastbody + 1, Editor:GetNoteSlideBodyX(note, lastbody))
            end
            i = i + 11
        elseif data[i] == 0x00 then
            if i == 14 + 12 * beatcount then
                firstnotetime = string.unpack('<i4', string.pack("BBBB", data[i + 2], data[i + 3], data[i + 4], data[i + 5]))
            end
            note = Editor:AddNote(1)
            Editor:SetNoteBeat(note, _beat(string.unpack('<i4', string.pack("BBBB", data[i + 2], data[i + 3], data[i + 4], data[i + 5]))), 1)
            Editor:SetNoteX(note, _x(data[i + 6]))
            Editor:SetNoteWidth(note, _width(0))
            i = i + 11
        elseif data[i] == 0x01 then
            if i == 14 + 12 * beatcount then
                firstnotetime = string.unpack('<i4', string.pack("BBBB", data[i + 2], data[i + 3], data[i + 4], data[i + 5]))
            end
            note = Editor:AddNote(1)
            if string.unpack('<i4', string.pack("BBBB", data[i + 7], data[i + 8], data[i + 9], data[i + 10])) > 0 then
                noteflag = 2
            else
                noteflag = 8
            end
            Editor:SetNoteBeat(note, _beat(string.unpack('<i4', string.pack("BBBB", data[i + 2], data[i + 3], data[i + 4], data[i + 5]))), 1)
            Editor:SetNoteX(note, _x(data[i + 6]))
            Editor:SetNoteWidth(note, _width(string.unpack('<i4', string.pack("BBBB", data[i + 7], data[i + 8], data[i + 9], data[i + 10]))))
            Editor:SetNoteFlag(note, noteflag)
            i = i + 11
        elseif data[i] == 0x02 then
            if i == 14 + 12 * beatcount then
                firstnotetime = string.unpack('<i4', string.pack("BBBB", data[i + 2], data[i + 3], data[i + 4], data[i + 5]))
            end
            note = Editor:AddNote(2048)
            Editor:SetNoteBeat(note, _beat(string.unpack('<i4', string.pack("BBBB", data[i + 2], data[i + 3], data[i + 4], data[i + 5]))), 1)
            Editor:SetNoteX(note, _x(data[i + 6]))
            Editor:SetNoteWidth(note, _width(0))
            Editor:AddNoteSlideBody(note, _slidebodybeat(string.unpack('<i4', string.pack("BBBB", data[i + 7], data[i + 8], data[i + 9], data[i + 10]))))
            i = i + 11
        else
            Editor:ShowMessage('imd存在错误，转换终止')
            return
        end
    end
end    


function split(str, reps)
    local resultStrList = {}
    string.gsub(str, '[^'..reps..']+', function (w)
        table.insert(resultStrList, w)
    end)
    return resultStrList
end

function _x(c)
    if column == 4 then
        return (c * 64 + 31)
    elseif column == 5 then
        return (c * 51 + 25)
    else
        return (c * 43 + 21)
    end
end

function _beat(time)
    local beat = (time - firstnotetime) * bpm // 60000 
    local numor = ((time - firstnotetime) * bpm % 60000) // 625
    local denom = 96
    local gcd_ = gcd(numor, denom)
    numor = numor // gcd_ --修改分度，以便可以在编辑器中修改
    denom = denom // gcd_ --修改分度，以便可以在编辑器中修改
    local newbeat = Editor:MakeBeat(beat, numor, denom)
    newbeat = Editor:BeatAdd(startbeat, newbeat)
    return newbeat
end

function _slidebodybeat(time)
    local beat = time * bpm // 60000 
    local numor = (time * bpm % 60000) // 625
    local denom = 96
    local gcd_ = gcd(numor, denom)
    numor = numor // gcd_ --修改分度，以便可以在编辑器中修改
    denom = denom // gcd_ --修改分度，以便可以在编辑器中修改
    local newbeat = Editor:MakeBeat(beat, numor, denom)
    return newbeat
end

function _width(num)
    local width = 0
    if column == 4 then
        width = 60 + abs(num)
    elseif column == 5 then
        width = 50 + abs(num)
    else
        width = 40 + abs(num)
    end
    return width
end

function abs(a)
    a = tonumber(a)
    if a >= 0 then
        return a
    else
        return -a
    end
end

function gcd(a, b)
    if a == 0 then return b end
    if b == 0 then return a end
    while(1)
    do
        if a > b then
            a = a % b
            if a == 0 then
                return b
            end
        else
            b = b % a
            if b == 0 then
                return a
            end
        end
    end
end