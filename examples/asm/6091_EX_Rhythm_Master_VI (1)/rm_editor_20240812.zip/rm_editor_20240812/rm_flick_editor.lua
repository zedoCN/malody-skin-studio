-- RM_Slide_Plugin v2.6 by dreamcat & Ramsey45 -- -- -- -- apply to MalodyV 6.0.40 -- 

PluginIcon = 'tailsl.png'
PluginName = 'rm_slide_editor'
PluginMode = 7
PluginType = 2
PluginRequire = '6.0.40'


pictable = {0,0,0,0}
bodytable = {0,0,0,0}
fbodytable = {0,0,0,0}
tailtable = {0,0,0,0}
tailtritable = {0,0,0,0}
rm_column=0
startnote=nil
selectnote=nil
moveflag=0
globalcolumn = 0
multiselect = {}

function OnClick()
    globalcolumn = tonumber(Editor:ReadData(520, 1314))
    if globalcolumn == 4 or globalcolumn == 5 or globalcolumn == 6 then
        rm_column = globalcolumn
    end
    local notecount=Editor:GetNoteCount()
    if rm_column==0 then
        for i=0,notecount-1 do
            local noteid=Editor:GetNoteAt(i)
            local notetype=Editor:GetNoteType(noteid)
            if notetype==1 or notetype==2048 then
                local notewidth=Editor:GetNoteWidth(noteid)
                if notewidth>=57 then
                    rm_column=4
                    Editor:WriteData(520, 1314, rm_column)
                    Editor:ShowMessage("4k Seleted")
                elseif notewidth>=47 and notewidth<57 then
                    rm_column=5
                    Editor:WriteData(520, 1314, rm_column)
                    Editor:ShowMessage("5k Seleted")
                else
                    rm_column=6
                    Editor:WriteData(520, 1314, rm_column)
                    Editor:ShowMessage("6k Seleted")
                end
                showpic()
                setglobalkey()
                return
            end
        end
    end
    
    if rm_column==0 then
        Editor:GetUserInput('Please enter the key number 请输入key数 (4/5/6)', '4/5/6', getcolumn)
        return
    end

    getglobalkey()
    local clickx=Editor:GetClickX()
    local clickbeat=Editor:GetClickBeat()
    if startnote==nil then
        if clickx<0 or clickx>255 then
            selectnote=nil
            cleartable(multiselect)
            shownote('frame')
            setglobalkey()
            return
        end
        
        local notecount=Editor:GetNoteCount()
        for i=0,notecount-1 do
            local noteid=Editor:GetNoteAt(i)
            local notex=Editor:GetNoteX(noteid)
            local notebeat=Editor:GetNoteBeat(noteid,true)
            if near(clickbeat,notebeat)>0 and x2c(clickx)==x2c(notex) then
                local notetype=Editor:GetNoteType(noteid)
                
                if notetype==1 and Editor:GetNoteFlag(noteid)>0 then
                    startnote=noteid
                    selectnote=noteid
                    cleartable(multiselect)
                    shownote('text')
                    shownote('frame')
                    shownote(startnote)
                    setglobalkey()
                    return
                else
                    selectnote=noteid
                    cleartable(multiselect)
                    shownote('frame')
                    shownote(selectnote)
                    setglobalkey()
                    return
                end
            end
            
        end
        if selectnote~=nil then
            selectnote=nil
            shownote('frame')
            setglobalkey()
            return
        end
        if #multiselect > 0 then
            cleartable(multiselect)
            shownote('frame')
            setglobalkey()
            return
        end
        startnote=Editor:AddNote(1)
        selectnote=startnote
        Editor:SetNoteWidth(startnote,(10-rm_column)*10+1)
        if clickx<128 then
            Editor:SetNoteFlag(startnote,2)
        else
            Editor:SetNoteFlag(startnote,8)
        end
        Editor:SetNoteX(startnote,x2cx(clickx))
        Editor:SetNoteBeat(startnote,clickbeat,true)
    else
        if clickx<0 or clickx>255 then
            Editor:RemoveModule('edittext')
            startnote=nil
            selectnote=nil
            shownote('text')
            shownote('frame')
            setglobalkey()
            return
        end
        local notebeat=Editor:GetNoteBeat(startnote,true)
        local notex=Editor:GetNoteX(startnote)
        if easyjudge(Editor:BeatMinus(clickbeat,notebeat))==0 then
            if x2c(clickx)==x2c(notex) then
                Editor:RemoveModule('edittext')
                startnote=nil 
                selectnote=nil
                shownote('text')
                shownote('frame')
                setglobalkey()
                return
            else
                if x2c(clickx)>x2c(notex) then
                    Editor:SetNoteFlag(startnote,2)
                    Editor:SetNoteWidth(startnote,(10-rm_column)*10+x2c(clickx)-x2c(notex))
                else
                    Editor:SetNoteFlag(startnote,8)
                    Editor:SetNoteWidth(startnote,(10-rm_column)*10+x2c(notex)-x2c(clickx))
                end
            end
        else
            Editor:RemoveModule('edittext')
            startnote=nil
            selectnote=nil
            shownote('text')
            shownote('frame')
            setglobalkey()
            return
        end
    end
    shownote('text')
    shownote('frame')
    shownote(selectnote)
    setglobalkey()
end

function OnDragStart()
    globalcolumn = tonumber(Editor:ReadData(520, 1314))
    if globalcolumn == 4 or globalcolumn == 5 or globalcolumn == 6 then
        rm_column = globalcolumn
    end
    local notecount=Editor:GetNoteCount()
    if rm_column==0 then
        for i=0,notecount-1 do
            local noteid=Editor:GetNoteAt(i)
            local notetype=Editor:GetNoteType(noteid)
            if notetype==1 or notetype==2048 then
                local notewidth=Editor:GetNoteWidth(noteid)
                if notewidth>=57 then
                    rm_column=4
                    Editor:WriteData(520, 1314, rm_column)
                    Editor:ShowMessage("4k Seleted")
                elseif notewidth>=47 and notewidth<57 then
                    rm_column=5
                    Editor:WriteData(520, 1314, rm_column)
                    Editor:ShowMessage("5k Seleted")
                else
                    rm_column=6
                    Editor:WriteData(520, 1314, rm_column)
                    Editor:ShowMessage("6k Seleted")
                end
                showpic()
                setglobalkey()
                return
            end
        end
    end

    if rm_column==0 then
        Editor:GetUserInput('Please enter the key number 请输入key数 (4/5/6)', '4/5/6', getcolumn)
        return
    end

    getglobalkey()
    startx = Editor:GetClickX()
    startbeat = Editor:GetClickBeatFree()
    local tempbeat = Editor:GetClickBeat()
    corenote = nil
    for k, v in pairs(multiselect) do
        if x2c(startx) == x2c(Editor:GetNoteX(v)) and near(Editor:GetNoteBeat(v, 1), tempbeat) > 0 then
            corenote = v
        end
    end
    if selectnote ~= nil and x2c(startx) == x2c(Editor:GetNoteX(selectnote)) and near(Editor:GetNoteBeat(selectnote, 1), tempbeat) > 0 then
        moveflag = 1
    elseif #multiselect > 0 and corenote ~= nil then
        moveflag = 2
    else
        moveflag = 0
        frame = Editor:AddSprite('frame', 'frame.png')
    end
end

function OnDragMove()
    if moveflag == 0 then
        frame.Beat = beataverage(startbeat, Editor:GetClickBeatFree())
        frame.X = (startx + Editor:GetClickX()) * 50 / 255
        frame.Width = math.abs(Editor:GetClickX() - startx) * 100 / 255
        frame.HeightBeat = Editor:BeatMinus(startbeat, Editor:GetClickBeatFree())
        if frame.HeightBeat.beat < 0 or frame.HeightBeat.numor < 0 then
            frame.HeightBeat = Editor:BeatMinus(Editor:GetClickBeatFree(), startbeat)
        end
    elseif moveflag == 1 then
        Editor:SetNoteX(selectnote, x2cx(Editor:GetClickX()))
        Editor:SetNoteBeat(selectnote, Editor:GetClickBeat(), 1)
        shownote('frame')
        shownote('text')
        shownote(selectnote)
    else
        local movex = x2cx(Editor:GetClickX()) - Editor:GetNoteX(corenote)
        local movebeat = Editor:BeatMinus(Editor:GetClickBeat(), Editor:GetNoteBeat(corenote, 1))
        for k, v in pairs(multiselect) do
            Editor:SetNoteX(v, Editor:GetNoteX(v) + movex)
            Editor:SetNoteBeat(v, Editor:BeatAdd(Editor:GetNoteBeat(v, 1), movebeat), 1)
            shownote(v)
        end
        shownote('frame')
    end
end

function OnDragEnd()
    if moveflag == 0 then
        endx = Editor:GetClickX()
        endbeat = Editor:GetClickBeatFree()
        Editor:RemoveModule('frame')
        local notecount = Editor:GetNoteCount()
        if notecount ~= 0 then
            if startnote ~= nil then
                Editor:RemoveModule('edittext')
            end
            local nid = nil
            for i = 0, notecount - 1, 1 do
                nid = Editor:GetNoteAt(i)
                if ((Editor:GetNoteX(nid) - startx) * (Editor:GetNoteX(nid) - endx) < 0 and easyjudge(Editor:BeatMinus(Editor:GetNoteBeat(nid, 1), startbeat)) * easyjudge(Editor:BeatMinus(Editor:GetNoteBeat(nid, 1), endbeat)) < 0) then
                    startnote = nil
                    selectnote = nil
                    table.insert(multiselect, nid)
                    Editor:AddSprite('selectframe'..nid, 'selectframe.png')
                end
            end
            shownote('frame')
            setglobalkey()
        end
    else
        moveflag = 0
    end
end

function OnActive()
    globalcolumn = tonumber(Editor:ReadData(520, 1314))
    if globalcolumn == 4 or globalcolumn == 5 or globalcolumn == 6 then
        rm_column = globalcolumn
    end
    local notecount=Editor:GetNoteCount()
    if rm_column==0 then
        for i=0,notecount-1 do
            local noteid=Editor:GetNoteAt(i)
            local notetype=Editor:GetNoteType(noteid)
            if notetype==1 or notetype==2048 then
                local notewidth=Editor:GetNoteWidth(noteid)
                if notewidth>=57 then
                    rm_column=4
                    Editor:WriteData(520, 1314, rm_column)
                    Editor:ShowMessage("4k Seleted")
                elseif notewidth>=47 and notewidth<57 then
                    rm_column=5
                    Editor:WriteData(520, 1314, rm_column)
                    Editor:ShowMessage("5k Seleted")
                else
                    rm_column=6
                    Editor:WriteData(520, 1314, rm_column)
                    Editor:ShowMessage("6k Seleted")
                end
                showpic()
                setglobalkey()
                return
            end
        end
    end
    
    if rm_column==0 then
        Editor:GetUserInput('Please enter the key number 请输入key数 (4/5/6)', '4/5/6', getcolumn)
        return
    end

    pictable = split(Editor:ReadData('pic', 123), '|')
    bodytable = split(Editor:ReadData('body', 123), '|')
    fbodytable = split(Editor:ReadData('fbody', 123), '|')
    tailtable = split(Editor:ReadData('tail', 123), '|')
    tailtritable = split(Editor:ReadData('tailtri', 123), '|')
end

function OnDeactive()
    Editor:RemoveModule('edittext')
    startnote = nil
    selectnote = nil
    cleartable(multiselect)
    shownote('text')
    shownote('frame')
    setglobalkey()
end

function getcolumn(text)
    if tonumber(text)==4 then
        rm_column=4
        Editor:WriteData(520, 1314, rm_column)
        Editor:ShowMessage("4k Seleted")
    elseif tonumber(text)==5 then
        rm_column=5
        Editor:WriteData(520, 1314, rm_column)
        Editor:ShowMessage("5k Seleted")
    elseif tonumber(text)==6 then
        rm_column=6
        Editor:WriteData(520, 1314, rm_column)
        Editor:ShowMessage("6k Seleted")
    else
        Editor:ShowMessage("Please Enter 4 5 6")
    end
end
function x2c(x)
    if rm_column==4 then
        cx=x//64+1
    elseif rm_column==5 then
        cx=x//51+1
    else
        cx=x//43+1
    end
    return cx
end
function x2cx(x)
    if rm_column==4 then
        cx=x//64*64+31
    elseif rm_column==5 then
        cx=x//51*51+25
    else
        cx=x//43*43+21
    end
    return cx
end
function x2w()
    if rm_column==4 then
        return 64
    elseif rm_column==5 then
        return 51
    else
        return 43
    end
end
function easyjudge(diff)
    if diff.beat < 0 or diff.numor < 0 then
        return -1
    elseif diff.beat == 0 and diff.numor == 0 then
        return 0
    else
        return 1
    end
end
function showpic()
    local notenum = Editor:GetNoteCount()
    local noteid = nil
    local pic = nil
    local notebody, notefbody, tail, tailtri = nil
    local bodycount = 0
    local zerobeat = {beat=0, numor=0, denom=1}
    local half = {beat=0, numor=0, denom=1}
    for i = 1, #pictable, 1 do
        if pictable[i] > 0 then
            Editor:RemoveModule('pic'..pictable[i])
            pictable[i] = - pictable[i]
        end
    end
    for i = 1, #bodytable, 1 do
        if bodytable[i] > 0 then
            Editor:RemoveModule('body'..bodytable[i])
            bodytable[i] = - bodytable[i]
        end
    end
    for i = 1, #fbodytable, 1 do
        if fbodytable[i] > 0 then
            Editor:RemoveModule('fbody'..fbodytable[i])
            fbodytable[i] = - fbodytable[i]
        end
    end
    for i = 1, #tailtable, 1 do
        if tailtable[i] > 0 then
            Editor:RemoveModule('tail'..tailtable[i])
            tailtable[i] = - tailtable[i]
        end
    end
    for i = 1, #tailtritable, 1 do
        if tailtritable[i] > 0 then
            Editor:RemoveModule('tailtri'..tailtritable[i])
            tailtritable[i] = - tailtritable[i]
        end
    end
    for i = 0, notenum - 1, 1 do
        noteid = Editor:GetNoteAt(i)
        if Editor:GetNoteType(noteid) == 1 then
            if Editor:GetNoteFlag(noteid) == 2 then
                pic = Editor:AddSprite("pic"..noteid,"pic_hold.png")
                notefbody = Editor:AddSprite('fbody'..(99999 * noteid), 'notefbody.png')
                notefbody.X = (Editor:GetNoteX(noteid) + FlickWidth(Editor:GetNoteWidth(noteid))/2)*100/255
                notefbody.Beat = Editor:GetNoteBeat(noteid,true)
                notefbody.Width = FlickWidth(Editor:GetNoteWidth(noteid))*100/255
                notefbody.HeightBeat = {beat=0, numor=1, denom=2}
                table.insert(fbodytable, 99999 * noteid)
                tailtri = Editor:AddSprite('tailtri'..noteid, 'tailsr.png')
                tailtri.X = (Editor:GetNoteX(noteid) + FlickWidth(Editor:GetNoteWidth(noteid)))*100/255
                tailtri.Beat = Editor:GetNoteBeat(noteid,true)
                tailtri.Width = 40 / rm_column
                tailtri.HeightBeat = {beat=0, numor=1, denom=4}
                table.insert(tailtritable, noteid)
            elseif Editor:GetNoteFlag(noteid) == 8 then
                pic = Editor:AddSprite("pic"..noteid,"pic_hold.png")
                notefbody = Editor:AddSprite('fbody'..(99999 * noteid), 'notefbody.png')
                notefbody.X = (Editor:GetNoteX(noteid) - FlickWidth(Editor:GetNoteWidth(noteid))/2)*100/255
                notefbody.Beat = Editor:GetNoteBeat(noteid,true)
                notefbody.Width = FlickWidth(Editor:GetNoteWidth(noteid))*100/255
                notefbody.HeightBeat = {beat=0, numor=1, denom=2}
                table.insert(fbodytable, 99999 * noteid)
                tailtri = Editor:AddSprite('tailtri'..noteid, 'tailsl.png')
                tailtri.X = (Editor:GetNoteX(noteid) - FlickWidth(Editor:GetNoteWidth(noteid)))*100/255
                tailtri.Beat = Editor:GetNoteBeat(noteid,true)
                tailtri.Width = 40 / rm_column
                tailtri.HeightBeat = {beat=0, numor=1, denom=4}
                table.insert(tailtritable, noteid)
            else
                pic = Editor:AddSprite('pic'..noteid, 'pic_tap.png')
            end
            pic.Beat = Editor:GetNoteBeat(noteid, 1)
            pic.X = Editor:GetNoteX(noteid) * 100 / 255
            pic.Width = 100 / rm_column
            pic.HeightBeat = {beat=0, numor=1, denom=16}
            table.insert(pictable, noteid)
        elseif Editor:GetNoteType(noteid) == 2048 then
            pic = Editor:AddSprite('pic'..noteid, 'pic_hold.png')
            pic.Beat = Editor:GetNoteBeat(noteid, 1)
            pic.X = Editor:GetNoteX(noteid) * 100 / 255
            pic.Width = 100 / rm_column
            pic.HeightBeat = {beat=0, numor=1, denom=16}
            bodycount = Editor:GetNoteSlideBodyCount(noteid)
            if bodycount ~= 0 then
                for j = 0, bodycount - 1, 1 do
                    if j == 0 then
                        notebody = Editor:AddSprite('body'..(99999 * noteid + j), 'notebody.png')
                        half = beataverage(zerobeat, Editor:GetNoteSlideBodyBeat(noteid, 0))
                        notebody.Beat = Editor:BeatAdd(Editor:GetNoteBeat(noteid, 1), half)
                        notebody.X = Editor:GetNoteX(noteid) * 100 / 255
                        notebody.Width = 200 / rm_column
                        notebody.HeightBeat = Editor:GetNoteSlideBodyBeat(noteid, 0)
                        notefbody = Editor:AddSprite('fbody'..(99999 * noteid + j), 'notefbody.png')
                        notefbody.Beat = Editor:BeatAdd(Editor:GetNoteBeat(noteid, 1), Editor:GetNoteSlideBodyBeat(noteid, 0))
                        notefbody.X = (Editor:GetNoteX(noteid) + Editor:GetNoteSlideBodyX(noteid, 0) / 2) * 100 / 255
                        notefbody.Width = math.abs(Editor:GetNoteSlideBodyX(noteid, 0)) * 115 / 255
                        notefbody.HeightBeat = {beat=0, numor=1, denom=2}
                    else
                        notebody = Editor:AddSprite('body'..(99999 * noteid + j), 'notebody.png')
                        half = beataverage(Editor:GetNoteSlideBodyBeat(noteid, j), Editor:GetNoteSlideBodyBeat(noteid, j - 1))
                        notebody.Beat = Editor:BeatAdd(Editor:GetNoteBeat(noteid, 1), half)
                        notebody.X = (Editor:GetNoteSlideBodyX(noteid, j - 1) + Editor:GetNoteX(noteid)) * 100 / 255
                        notebody.Width = 200 / rm_column
                        notebody.HeightBeat = Editor:BeatMinus(Editor:GetNoteSlideBodyBeat(noteid, j), Editor:GetNoteSlideBodyBeat(noteid, j - 1))
                        notefbody = Editor:AddSprite('fbody'..(99999 * noteid + j), 'notefbody.png')
                        notefbody.Beat = Editor:BeatAdd(Editor:GetNoteBeat(noteid, 1), Editor:GetNoteSlideBodyBeat(noteid, j))
                        notefbody.X = (Editor:GetNoteX(noteid) + (Editor:GetNoteSlideBodyX(noteid, j - 1) + Editor:GetNoteSlideBodyX(noteid, j)) / 2) * 100 / 255
                        notefbody.Width = math.abs(Editor:GetNoteSlideBodyX(noteid, j) - Editor:GetNoteSlideBodyX(noteid, j - 1)) * 115 / 255
                        notefbody.HeightBeat = {beat=0, numor=1, denom=2}
                    end
                    table.insert(bodytable, 99999 * noteid + j)
                    table.insert(fbodytable, 99999 * noteid + j)
                end
                if bodycount == 1 then
                    if Editor:GetNoteSlideBodyX(noteid, 0) ~= 0 then
                        if Editor:GetNoteSlideBodyX(noteid, 0) > 0 then
                            tailtri = Editor:AddSprite('tailtri'..noteid, 'tailsr.png')
                        else
                            tailtri = Editor:AddSprite('tailtri'..noteid, 'tailsl.png')
                        end
                        tailtri.Beat = Editor:BeatAdd(Editor:GetNoteBeat(noteid, 1), Editor:GetNoteSlideBodyBeat(noteid, 0))
                        tailtri.X = (Editor:GetNoteX(noteid) + Editor:GetNoteSlideBodyX(noteid, 0)) * 100 / 255
                        tailtri.Width = 40 / rm_column
                        tailtri.HeightBeat = {beat=0, numor=1, denom=4}
                    else
                        tail = Editor:AddSprite('tail'..noteid, 'tail.png')
                        tail.Beat = Editor:BeatAdd(Editor:GetNoteBeat(noteid, 1), Editor:GetNoteSlideBodyBeat(noteid, 0))
                        tail.X = (Editor:GetNoteX(noteid) + Editor:GetNoteSlideBodyX(noteid, 0)) * 100 / 255
                        tail.Width = 75 / rm_column
                        tail.HeightBeat = {beat=0, numor=1, denom=4}
                    end
                else
                    if Editor:GetNoteSlideBodyX(noteid, bodycount - 1) ~= Editor:GetNoteSlideBodyX(noteid, bodycount - 2) then
                        if Editor:GetNoteSlideBodyX(noteid, bodycount - 1) > Editor:GetNoteSlideBodyX(noteid, bodycount - 2) then
                            tailtri = Editor:AddSprite('tailtri'..noteid, 'tailsr.png')
                        else
                            tailtri = Editor:AddSprite('tailtri'..noteid, 'tailsl.png')
                        end
                        tailtri.Beat = Editor:BeatAdd(Editor:GetNoteBeat(noteid, 1), Editor:GetNoteSlideBodyBeat(noteid, bodycount - 1))
                        tailtri.X = (Editor:GetNoteX(noteid) + Editor:GetNoteSlideBodyX(noteid, bodycount - 1)) * 100 / 255
                        tailtri.Width = 40 / rm_column
                        tailtri.HeightBeat = {beat=0, numor=1, denom=4}
                    else
                        tail = Editor:AddSprite('tail'..noteid, 'tail.png')
                        tail.Beat = Editor:BeatAdd(Editor:GetNoteBeat(noteid, 1), Editor:GetNoteSlideBodyBeat(noteid, bodycount - 1))
                        tail.X = (Editor:GetNoteX(noteid) + Editor:GetNoteSlideBodyX(noteid, bodycount - 1)) * 100 / 255
                        tail.Width = 75 / rm_column
                        tail.HeightBeat = {beat=0, numor=1, denom=4}
                    end
                end
                table.insert(tailtritable, noteid)
                table.insert(tailtable, noteid)
            end
            table.insert(pictable, noteid)
        else
            
        end
    end
    if startnote ~= nil then
        local counttemp = Editor:GetNoteSlideBodyCount(startnote)
        if counttemp == 0 then
            local edittext = Editor:AddText('edittext', '正在编辑')
            edittext.Beat = Editor:BeatAdd(Editor:GetNoteBeat(startnote, 1), Editor:MakeBeat(0, 1, 16))
            edittext.X = Editor:GetNoteX(startnote) * 100 / 255 - 4
            edittext.Width = 16
        else
            Editor:RemoveModule('edittext')
            local edittext = Editor:AddText('edittext', '正在编辑')
            edittext.Beat = Editor:BeatAdd(Editor:BeatAdd(Editor:GetNoteBeat(startnote, 1), Editor:GetNoteSlideBodyBeat(startnote, counttemp - 1)), Editor:MakeBeat(0, 1, 16))
            edittext.X = (Editor:GetNoteX(startnote) + Editor:GetNoteSlideBodyX(startnote, counttemp - 1)) * 100 / 255 - 4
            edittext.Width = 16
        end
    else
        Editor:RemoveModule('edittext')
    end
    if selectnote ~= nil then
        Editor:RemoveModule('selectframe')
        local selectframe = Editor:AddSprite('selectframe', 'selectframe.png')
        selectframe.X = Editor:GetNoteX(selectnote) * 100 / 255
        selectframe.Width = 200 / rm_column
        selectframe.Beat = Editor:GetNoteBeat(selectnote, 1)
        selectframe.HeightBeat = Editor:MakeBeat(0, 1, 4)
    else
        Editor:RemoveModule('selectframe')
    end
    if #multiselect > 0 then
        local multiframe = nil
        for k, v in pairs(multiselect) do
            Editor:RemoveModule('selectframe'..v)
            multiframe = Editor:AddSprite('selectframe'..v, 'selectframe.png')
            multiframe.X = Editor:GetNoteX(v) * 100 / 255
            multiframe.Width = 200 / rm_column
            multiframe.Beat = Editor:GetNoteBeat(v, 1)
            multiframe.HeightBeat = Editor:MakeBeat(0, 1, 4)
        end
    end
end

function AdjustX(y)
    if rm_column == 4 then
        return ((y // 64) * 64 + 31)
    elseif rm_column == 5 then
        return ((y // 51) * 51 + 25)
    else
        return ((y // 43) * 43 + 21)
    end
end



function beataverage(a, b)
    local result = {beat = 0, numor = 0, denom = 0}
    if (a.beat + b.beat) % 2 == 0 then
        result.beat = (a.beat + b.beat) / 2
        result.numor = a.numor * b.denom + b.numor * a.denom
        result.denom = 2 * a.denom * b.denom
    else
        result.beat = (a.beat + b.beat) // 2
        result.numor = a.numor * b.denom + b.numor * a.denom + a.denom * b.denom
        result.denom = 2 * a.denom * b.denom
    end
    return result
end
function FlickWidth(width)
    if rm_column==4 then
        fwidth=64*(width%10)
    elseif rm_column==5 then
        fwidth=51*(width%10)
    elseif rm_column==6 then
        fwidth=43*(width%10)
    end
    return fwidth
end

function cleartable(tb)
    if tb == nil or #tb == 0 then
        return
    else
        for i = #tb, 1, -1 do
            Editor:RemoveModule('selectframe'..tb[i])
            table.remove(tb, i)
        end
    end
end

function shownote(noteid)
    local pic = nil
    local notebody, notefbody, tail, tailtri = nil
    local bodycount = 0
    local zerobeat = {beat=0, numor=0, denom=1}
    local half = {beat=0, numor=0, denom=1}
    if noteid == 'text' then
        if startnote ~= nil then
            local counttemp = Editor:GetNoteSlideBodyCount(startnote)
            if counttemp == 0 then
                local edittext = Editor:AddText('edittext', '正在编辑')
                edittext.Beat = Editor:BeatAdd(Editor:GetNoteBeat(startnote, 1), Editor:MakeBeat(0, 1, 16))
                edittext.X = Editor:GetNoteX(startnote) * 100 / 255 - 4
                edittext.Width = 16
            else
                Editor:RemoveModule('edittext')
                local edittext = Editor:AddText('edittext', '正在编辑')
                edittext.Beat = Editor:BeatAdd(Editor:BeatAdd(Editor:GetNoteBeat(startnote, 1), Editor:GetNoteSlideBodyBeat(startnote, counttemp - 1)), Editor:MakeBeat(0, 1, 16))
                edittext.X = (Editor:GetNoteX(startnote) + Editor:GetNoteSlideBodyX(startnote, counttemp - 1)) * 100 / 255 - 4
                edittext.Width = 16
            end
        end
        return
    end
    if noteid == 'frame' then
        if selectnote ~= nil then
            Editor:RemoveModule('selectframe')
            local selectframe = Editor:AddSprite('selectframe', 'selectframe.png')
            selectframe.X = Editor:GetNoteX(selectnote) * 100 / 255
            selectframe.Width = 200 / rm_column
            selectframe.Beat = Editor:GetNoteBeat(selectnote, 1)
            selectframe.HeightBeat = Editor:MakeBeat(0, 1, 4)
        else
            Editor:RemoveModule('selectframe')
        end
        if #multiselect > 0 then
            local multiframe = nil
            for k, v in pairs(multiselect) do
                Editor:RemoveModule('selectframe'..v)
                multiframe = Editor:AddSprite('selectframe'..v, 'selectframe.png')
                multiframe.X = Editor:GetNoteX(v) * 100 / 255
                multiframe.Width = 200 / rm_column
                multiframe.Beat = Editor:GetNoteBeat(v, 1)
                multiframe.HeightBeat = Editor:MakeBeat(0, 1, 4)
            end
        end
        return
    end
    if Editor:GetNoteType(noteid) == 1 then
        Editor:RemoveModule('pic'..noteid)
        removeitem(pictable, noteid)
        if Editor:GetNoteFlag(noteid) == 2 then
            Editor:RemoveModule('fbody'..(99999 * noteid))
            removeitem(fbodytable, 99999 * noteid)
            Editor:RemoveModule('tailtri'..noteid)
            removeitem(tailtritable, noteid)
            pic = Editor:AddSprite("pic"..noteid,"pic_hold.png")
            notefbody = Editor:AddSprite('fbody'..(99999 * noteid), 'notefbody.png')
            notefbody.X = (Editor:GetNoteX(noteid) + FlickWidth(Editor:GetNoteWidth(noteid))/2)*100/255
            notefbody.Beat = Editor:GetNoteBeat(noteid,true)
            notefbody.Width = FlickWidth(Editor:GetNoteWidth(noteid))*100/255
            notefbody.HeightBeat = {beat=0, numor=1, denom=2}
            table.insert(fbodytable, 99999 * noteid)
            tailtri = Editor:AddSprite('tailtri'..noteid, 'tailsr.png')
            tailtri.X = (Editor:GetNoteX(noteid) + FlickWidth(Editor:GetNoteWidth(noteid)))*100/255
            tailtri.Beat = Editor:GetNoteBeat(noteid,true)
            tailtri.Width = 40 / rm_column
            tailtri.HeightBeat = {beat=0, numor=1, denom=4}
            table.insert(tailtritable, noteid)
        elseif Editor:GetNoteFlag(noteid) == 8 then
            Editor:RemoveModule('fbody'..(99999 * noteid))
            removeitem(fbodytable, 99999 * noteid)
            Editor:RemoveModule('tailtri'..noteid)
            removeitem(tailtritable, noteid)
            pic = Editor:AddSprite("pic"..noteid,"pic_hold.png")
            notefbody = Editor:AddSprite('fbody'..(99999 * noteid), 'notefbody.png')
            notefbody.X = (Editor:GetNoteX(noteid) - FlickWidth(Editor:GetNoteWidth(noteid))/2)*100/255
            notefbody.Beat = Editor:GetNoteBeat(noteid,true)
            notefbody.Width = FlickWidth(Editor:GetNoteWidth(noteid))*100/255
            notefbody.HeightBeat = {beat=0, numor=1, denom=2}
            table.insert(fbodytable, 99999 * noteid)
            tailtri = Editor:AddSprite('tailtri'..noteid, 'tailsl.png')
            tailtri.X = (Editor:GetNoteX(noteid) - FlickWidth(Editor:GetNoteWidth(noteid)))*100/255
            tailtri.Beat = Editor:GetNoteBeat(noteid,true)
            tailtri.Width = 40 / rm_column
            tailtri.HeightBeat = {beat=0, numor=1, denom=4}
            table.insert(tailtritable, noteid)
        else
            pic = Editor:AddSprite('pic'..noteid, 'pic_tap.png')
        end
        pic.Beat = Editor:GetNoteBeat(noteid, 1)
        pic.X = Editor:GetNoteX(noteid) * 100 / 255
        pic.Width = 100 / rm_column
        pic.HeightBeat = {beat=0, numor=1, denom=16}
        table.insert(pictable, noteid)
    elseif Editor:GetNoteType(noteid) == 2048 then
        Editor:RemoveModule('pic'..noteid)
        removeitem(pictable, noteid)
        for i = #bodytable, 1, -1 do
            if bodytable[i] // 99999 == noteid then
                Editor:RemoveModule('body'..bodytable[i])
                table.remove(bodytable, i)
            end
        end
        for i = #fbodytable, 1, -1 do
            if fbodytable[i] // 99999 == noteid then
                Editor:RemoveModule('fbody'..fbodytable[i])
                table.remove(fbodytable, i)
            end
        end
        for i = #tailtable, 1, -1 do
            if tailtable[i] == noteid then
                Editor:RemoveModule('tail'..tailtable[i])
                table.remove(tailtable, i)
            end
        end
        for i = #tailtritable, 1, -1 do
            if tailtritable[i] == noteid then
                Editor:RemoveModule('tailtri'..tailtritable[i])
                table.remove(tailtritable, i)
            end
        end
        pic = Editor:AddSprite('pic'..noteid, 'pic_hold.png')
        pic.Beat = Editor:GetNoteBeat(noteid, 1)
        pic.X = Editor:GetNoteX(noteid) * 100 / 255
        pic.Width = 100 / rm_column
        pic.HeightBeat = {beat=0, numor=1, denom=16}
        bodycount = Editor:GetNoteSlideBodyCount(noteid)
        if bodycount ~= 0 then
            for j = 0, bodycount - 1, 1 do
                if j == 0 then
                    notebody = Editor:AddSprite('body'..(99999 * noteid + j), 'notebody.png')
                    half = beataverage(zerobeat, Editor:GetNoteSlideBodyBeat(noteid, 0))
                    notebody.Beat = Editor:BeatAdd(Editor:GetNoteBeat(noteid, 1), half)
                    notebody.X = Editor:GetNoteX(noteid) * 100 / 255
                    notebody.Width = 200 / rm_column
                    notebody.HeightBeat = Editor:GetNoteSlideBodyBeat(noteid, 0)
                    notefbody = Editor:AddSprite('fbody'..(99999 * noteid + j), 'notefbody.png')
                    notefbody.Beat = Editor:BeatAdd(Editor:GetNoteBeat(noteid, 1), Editor:GetNoteSlideBodyBeat(noteid, 0))
                    notefbody.X = (Editor:GetNoteX(noteid) + Editor:GetNoteSlideBodyX(noteid, 0) / 2) * 100 / 255
                    notefbody.Width = math.abs(Editor:GetNoteSlideBodyX(noteid, 0)) * 115 / 255
                    notefbody.HeightBeat = {beat=0, numor=1, denom=2}
                else
                    notebody = Editor:AddSprite('body'..(99999 * noteid + j), 'notebody.png')
                    half = beataverage(Editor:GetNoteSlideBodyBeat(noteid, j), Editor:GetNoteSlideBodyBeat(noteid, j - 1))
                    notebody.Beat = Editor:BeatAdd(Editor:GetNoteBeat(noteid, 1), half)
                    notebody.X = (Editor:GetNoteSlideBodyX(noteid, j - 1) + Editor:GetNoteX(noteid)) * 100 / 255
                    notebody.Width = 200 / rm_column
                    notebody.HeightBeat = Editor:BeatMinus(Editor:GetNoteSlideBodyBeat(noteid, j), Editor:GetNoteSlideBodyBeat(noteid, j - 1))
                    notefbody = Editor:AddSprite('fbody'..(99999 * noteid + j), 'notefbody.png')
                    notefbody.Beat = Editor:BeatAdd(Editor:GetNoteBeat(noteid, 1), Editor:GetNoteSlideBodyBeat(noteid, j))
                    notefbody.X = (Editor:GetNoteX(noteid) + (Editor:GetNoteSlideBodyX(noteid, j - 1) + Editor:GetNoteSlideBodyX(noteid, j)) / 2) * 100 / 255
                    notefbody.Width = math.abs(Editor:GetNoteSlideBodyX(noteid, j) - Editor:GetNoteSlideBodyX(noteid, j - 1)) * 115 / 255
                    notefbody.HeightBeat = {beat=0, numor=1, denom=2}
                end
                table.insert(bodytable, 99999 * noteid + j)
                table.insert(fbodytable, 99999 * noteid + j)
            end
            if bodycount == 1 then
                if Editor:GetNoteSlideBodyX(noteid, 0) ~= 0 then
                    if Editor:GetNoteSlideBodyX(noteid, 0) > 0 then
                        tailtri = Editor:AddSprite('tailtri'..noteid, 'tailsr.png')
                    else
                        tailtri = Editor:AddSprite('tailtri'..noteid, 'tailsl.png')
                    end
                    tailtri.Beat = Editor:BeatAdd(Editor:GetNoteBeat(noteid, 1), Editor:GetNoteSlideBodyBeat(noteid, 0))
                    tailtri.X = (Editor:GetNoteX(noteid) + Editor:GetNoteSlideBodyX(noteid, 0)) * 100 / 255
                    tailtri.Width = 40 / rm_column
                    tailtri.HeightBeat = {beat=0, numor=1, denom=4}
                    table.insert(tailtritable, noteid)
                else
                    tail = Editor:AddSprite('tail'..noteid, 'tail.png')
                    tail.Beat = Editor:BeatAdd(Editor:GetNoteBeat(noteid, 1), Editor:GetNoteSlideBodyBeat(noteid, 0))
                    tail.X = (Editor:GetNoteX(noteid) + Editor:GetNoteSlideBodyX(noteid, 0)) * 100 / 255
                    tail.Width = 75 / rm_column
                    tail.HeightBeat = {beat=0, numor=1, denom=4}
                    table.insert(tailtable, noteid)
                end
            else
                if Editor:GetNoteSlideBodyX(noteid, bodycount - 1) ~= Editor:GetNoteSlideBodyX(noteid, bodycount - 2) then
                    if Editor:GetNoteSlideBodyX(noteid, bodycount - 1) > Editor:GetNoteSlideBodyX(noteid, bodycount - 2) then
                        tailtri = Editor:AddSprite('tailtri'..noteid, 'tailsr.png')
                    else
                        tailtri = Editor:AddSprite('tailtri'..noteid, 'tailsl.png')
                    end
                    tailtri.Beat = Editor:BeatAdd(Editor:GetNoteBeat(noteid, 1), Editor:GetNoteSlideBodyBeat(noteid, bodycount - 1))
                    tailtri.X = (Editor:GetNoteX(noteid) + Editor:GetNoteSlideBodyX(noteid, bodycount - 1)) * 100 / 255
                    tailtri.Width = 40 / rm_column
                    tailtri.HeightBeat = {beat=0, numor=1, denom=4}
                    table.insert(tailtritable, noteid)
                else
                    tail = Editor:AddSprite('tail'..noteid, 'tail.png')
                    tail.Beat = Editor:BeatAdd(Editor:GetNoteBeat(noteid, 1), Editor:GetNoteSlideBodyBeat(noteid, bodycount - 1))
                    tail.X = (Editor:GetNoteX(noteid) + Editor:GetNoteSlideBodyX(noteid, bodycount - 1)) * 100 / 255
                    tail.Width = 75 / rm_column
                    tail.HeightBeat = {beat=0, numor=1, denom=4}
                    table.insert(tailtable, noteid)
                end
            end
        end
        table.insert(pictable, noteid)
    else
        
    end
end

function split(str, reps)
    local resultStrList = {}
    if str == nil then return resultStrList end
    string.gsub(str, '[^'..reps..']+', function (w)
        table.insert(resultStrList, tonumber(w))
    end)
    return resultStrList
end

function removeitem(tb, value)
    for i = #tb, 1, -1 do
        if tb[i] == tonumber(value) then
            table.remove(tb, i)
            return
        end
    end
end

function setglobalkey()
    local item = ''
    if #pictable > 0 then
        for i = 1, #pictable do
            if i == 1 then
                item = item..pictable[i]
            else
                item = item..'|'..pictable[i]
            end
        end
    end
    Editor:WriteData('pic', 123, item)
    item = ''
    if #bodytable > 0 then
        for i = 1, #bodytable do
            if i == 1 then
                item = item..bodytable[i]
            else
                item = item..'|'..bodytable[i]
            end
        end
    end
    Editor:WriteData('body', 123, item)
    item = ''
    if #fbodytable > 0 then
        for i = 1, #fbodytable do
            if i == 1 then
                item = item..fbodytable[i]
            else
                item = item..'|'..fbodytable[i]
            end
        end
    end
    Editor:WriteData('fbody', 123, item)
    item = ''
    if #tailtable > 0 then
        for i = 1, #tailtable do
            if i == 1 then
                item = item..tailtable[i]
            else
                item = item..'|'..tailtable[i]
            end
        end
    end
    Editor:WriteData('tail', 123, item)
    item = ''
    if #tailtritable > 0 then
        for i = 1, #tailtritable do
            if i == 1 then
                item = item..tailtritable[i]
            else
                item = item..'|'..tailtritable[i]
            end
        end
    end
    Editor:WriteData('tailtri', 123, item)
    item = ''
    if #multiselect > 0 then
        for i = 1, #multiselect do
            if i == 1 then
                item = item..multiselect[i]
            else
                item = item..'|'..multiselect[i]
            end
        end
    end
    Editor:WriteData('multiselect', 123, item)
    Editor:WriteData('selected', 123, selectnote)
    Editor:WriteData('startnote', 123, startnote)
end

function getglobalkey()
    pictable = split(Editor:ReadData('pic', 123), '|')
    bodytable = split(Editor:ReadData('body', 123), '|')
    fbodytable = split(Editor:ReadData('fbody', 123), '|')
    tailtable = split(Editor:ReadData('tail', 123), '|')
    tailtritable = split(Editor:ReadData('tailtri', 123), '|')
    multiselect = split(Editor:ReadData('multiselect', 123), '|')
    startnote = tonumber(Editor:ReadData('startnote', 123))
    selectnote = tonumber(Editor:ReadData('selected', 123))
end

function near(beat1, beat2)
    local beat = Editor:BeatMinus(beat1, beat2)
    local val = math.abs(beat.beat + beat.numor / beat.denom)
    if val < 0.03125 then
        return 1
    else
        return 0
    end
end