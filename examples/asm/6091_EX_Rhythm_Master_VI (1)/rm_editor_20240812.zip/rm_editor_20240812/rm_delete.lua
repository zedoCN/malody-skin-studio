-- RM_Delete_Plugin v2.4 by Ramsey45 & dreamcat -- -- -- -- apply to MalodyV 6.0.40 -- 

PluginName = 'RM_Delete'
PluginMode = 7
PluginType = 0
PluginRequire = '6.0.40'

pictable = {0,0,0,0}
bodytable = {0,0,0,0}
fbodytable = {0,0,0,0}
tailtable = {0,0,0,0}
tailtritable = {0,0,0,0}
rm_column=0
startnote=nil
selectnote=nil
moveflag=0
globalcolumn = 0
multiselect = {}

function Run()
    getglobalkey()

    for k, noteid in pairs(multiselect) do
        Editor:DeleteNote(noteid)
        Editor:RemoveModule('selectframe'..noteid)
        Editor:RemoveModule('pic'..noteid)
        removeitem(pictable, noteid)
        for i = #bodytable, 1, -1 do
            if bodytable[i] // 99999 == noteid then
                Editor:RemoveModule('body'..bodytable[i])
                table.remove(bodytable, i)
            end
        end
        for i = #fbodytable, 1, -1 do
            if fbodytable[i] // 99999 == noteid then
                Editor:RemoveModule('fbody'..fbodytable[i])
                table.remove(fbodytable, i)
            end
        end
        for i = #tailtable, 1, -1 do
            if tailtable[i] == noteid then
                Editor:RemoveModule('tail'..tailtable[i])
                table.remove(tailtable, i)
            end
        end
        for i = #tailtritable, 1, -1 do
            if tailtritable[i] == noteid then
                Editor:RemoveModule('tailtri'..tailtritable[i])
                table.remove(tailtritable, i)
            end
        end
    end

    local noteid = selectnote
    if noteid ~= nil then
        Editor:DeleteNote(noteid)
        Editor:RemoveModule('selectframe')
        Editor:RemoveModule('edittext')
        Editor:RemoveModule('pic'..noteid)
        removeitem(pictable, noteid)
        for i = #bodytable, 1, -1 do
            if bodytable[i] // 99999 == noteid then
                Editor:RemoveModule('body'..bodytable[i])
                table.remove(bodytable, i)
            end
        end
        for i = #fbodytable, 1, -1 do
            if fbodytable[i] // 99999 == noteid then
                Editor:RemoveModule('fbody'..fbodytable[i])
                table.remove(fbodytable, i)
            end
        end
        for i = #tailtable, 1, -1 do
            if tailtable[i] == noteid then
                Editor:RemoveModule('tail'..tailtable[i])
                table.remove(tailtable, i)
            end
        end
        for i = #tailtritable, 1, -1 do
            if tailtritable[i] == noteid then
                Editor:RemoveModule('tailtri'..tailtritable[i])
                table.remove(tailtritable, i)
            end
        end
    end

    startnote = nil
    selectnote = nil
    if #multiselect > 0 then
        for i = #multiselect, 1, -1 do
            Editor:RemoveModule('selectframe'..multiselect[i])
            table.remove(multiselect, i)
        end
    end
    
    setglobalkey()
end

function split(str, reps)
    local resultStrList = {}
    if str == nil then return resultStrList end
    string.gsub(str, '[^'..reps..']+', function (w)
        table.insert(resultStrList, tonumber(w))
    end)
    return resultStrList
end

function shownote(noteid)
    local pic = nil
    local notebody, notefbody, tail, tailtri = nil
    local bodycount = 0
    local zerobeat = {beat=0, numor=0, denom=1}
    local half = {beat=0, numor=0, denom=1}
    if noteid == 'text' then
        if startnote ~= nil then
            local counttemp = Editor:GetNoteSlideBodyCount(startnote)
            if counttemp == 0 then
                local edittext = Editor:AddText('edittext', '正在编辑')
                edittext.Beat = Editor:BeatAdd(Editor:GetNoteBeat(startnote, 1), Editor:MakeBeat(0, 1, 16))
                edittext.X = Editor:GetNoteX(startnote) * 100 / 255 - 4
                edittext.Width = 16
            else
                Editor:RemoveModule('edittext')
                local edittext = Editor:AddText('edittext', '正在编辑')
                edittext.Beat = Editor:BeatAdd(Editor:BeatAdd(Editor:GetNoteBeat(startnote, 1), Editor:GetNoteSlideBodyBeat(startnote, counttemp - 1)), Editor:MakeBeat(0, 1, 16))
                edittext.X = (Editor:GetNoteX(startnote) + Editor:GetNoteSlideBodyX(startnote, counttemp - 1)) * 100 / 255 - 4
                edittext.Width = 16
            end
        end
        return
    end
    if noteid == 'frame' then
        if selectnote ~= nil then
            Editor:RemoveModule('selectframe')
            local selectframe = Editor:AddSprite('selectframe', 'selectframe.png')
            selectframe.X = Editor:GetNoteX(selectnote) * 100 / 255
            selectframe.Width = 200 / rm_column
            selectframe.Beat = Editor:GetNoteBeat(selectnote, 1)
            selectframe.HeightBeat = Editor:MakeBeat(0, 1, 4)
        else
            Editor:RemoveModule('selectframe')
        end
        if #multiselect > 0 then
            local multiframe = nil
            for k, v in pairs(multiselect) do
                Editor:RemoveModule('selectframe'..v)
                multiframe = Editor:AddSprite('selectframe'..v, 'selectframe.png')
                multiframe.X = Editor:GetNoteX(v) * 100 / 255
                multiframe.Width = 200 / rm_column
                multiframe.Beat = Editor:GetNoteBeat(v, 1)
                multiframe.HeightBeat = Editor:MakeBeat(0, 1, 4)
            end
        end
        return
    end
    if Editor:GetNoteType(noteid) == 1 then
        Editor:RemoveModule('pic'..noteid)
        removeitem(pictable, noteid)
        if Editor:GetNoteFlag(noteid) == 2 then
            Editor:RemoveModule('fbody'..(99999 * noteid))
            removeitem(fbodytable, 99999 * noteid)
            Editor:RemoveModule('tailtri'..noteid)
            removeitem(tailtritable, noteid)
            pic = Editor:AddSprite("pic"..noteid,"pic_hold.png")
            notefbody = Editor:AddSprite('fbody'..(99999 * noteid), 'notefbody.png')
            notefbody.X = (Editor:GetNoteX(noteid) + FlickWidth(Editor:GetNoteWidth(noteid))/2)*100/255
            notefbody.Beat = Editor:GetNoteBeat(noteid,true)
            notefbody.Width = FlickWidth(Editor:GetNoteWidth(noteid))*100/255
            notefbody.HeightBeat = {beat=0, numor=1, denom=2}
            table.insert(fbodytable, 99999 * noteid)
            tailtri = Editor:AddSprite('tailtri'..noteid, 'tailsr.png')
            tailtri.X = (Editor:GetNoteX(noteid) + FlickWidth(Editor:GetNoteWidth(noteid)))*100/255
            tailtri.Beat = Editor:GetNoteBeat(noteid,true)
            tailtri.Width = 40 / rm_column
            tailtri.HeightBeat = {beat=0, numor=1, denom=4}
            table.insert(tailtritable, noteid)
        elseif Editor:GetNoteFlag(noteid) == 8 then
            Editor:RemoveModule('fbody'..(99999 * noteid))
            removeitem(fbodytable, 99999 * noteid)
            Editor:RemoveModule('tailtri'..noteid)
            removeitem(tailtritable, noteid)
            pic = Editor:AddSprite("pic"..noteid,"pic_hold.png")
            notefbody = Editor:AddSprite('fbody'..(99999 * noteid), 'notefbody.png')
            notefbody.X = (Editor:GetNoteX(noteid) - FlickWidth(Editor:GetNoteWidth(noteid))/2)*100/255
            notefbody.Beat = Editor:GetNoteBeat(noteid,true)
            notefbody.Width = FlickWidth(Editor:GetNoteWidth(noteid))*100/255
            notefbody.HeightBeat = {beat=0, numor=1, denom=2}
            table.insert(fbodytable, 99999 * noteid)
            tailtri = Editor:AddSprite('tailtri'..noteid, 'tailsl.png')
            tailtri.X = (Editor:GetNoteX(noteid) - FlickWidth(Editor:GetNoteWidth(noteid)))*100/255
            tailtri.Beat = Editor:GetNoteBeat(noteid,true)
            tailtri.Width = 40 / rm_column
            tailtri.HeightBeat = {beat=0, numor=1, denom=4}
            table.insert(tailtritable, noteid)
        else
            pic = Editor:AddSprite('pic'..noteid, 'pic_tap.png')
        end
        pic.Beat = Editor:GetNoteBeat(noteid, 1)
        pic.X = Editor:GetNoteX(noteid) * 100 / 255
        pic.Width = 100 / rm_column
        pic.HeightBeat = {beat=0, numor=1, denom=16}
        table.insert(pictable, noteid)
    elseif Editor:GetNoteType(noteid) == 2048 then
        Editor:RemoveModule('pic'..noteid)
        removeitem(pictable, noteid)
        for i = #bodytable, 1, -1 do
            if bodytable[i] // 99999 == noteid then
                Editor:RemoveModule('body'..bodytable[i])
                table.remove(bodytable, i)
            end
        end
        for i = #fbodytable, 1, -1 do
            if fbodytable[i] // 99999 == noteid then
                Editor:RemoveModule('fbody'..fbodytable[i])
                table.remove(fbodytable, i)
            end
        end
        for i = #tailtable, 1, -1 do
            if tailtable[i] == noteid then
                Editor:RemoveModule('tail'..tailtable[i])
                table.remove(tailtable, i)
            end
        end
        for i = #tailtritable, 1, -1 do
            if tailtritable[i] == noteid then
                Editor:RemoveModule('tailtri'..tailtritable[i])
                table.remove(tailtritable, i)
            end
        end
        pic = Editor:AddSprite('pic'..noteid, 'pic_hold.png')
        pic.Beat = Editor:GetNoteBeat(noteid, 1)
        pic.X = Editor:GetNoteX(noteid) * 100 / 255
        pic.Width = 100 / rm_column
        pic.HeightBeat = {beat=0, numor=1, denom=16}
        bodycount = Editor:GetNoteSlideBodyCount(noteid)
        if bodycount ~= 0 then
            for j = 0, bodycount - 1, 1 do
                if j == 0 then
                    notebody = Editor:AddSprite('body'..(99999 * noteid + j), 'notebody.png')
                    half = beataverage(zerobeat, Editor:GetNoteSlideBodyBeat(noteid, 0))
                    notebody.Beat = Editor:BeatAdd(Editor:GetNoteBeat(noteid, 1), half)
                    notebody.X = Editor:GetNoteX(noteid) * 100 / 255
                    notebody.Width = 200 / rm_column
                    notebody.HeightBeat = Editor:GetNoteSlideBodyBeat(noteid, 0)
                    notefbody = Editor:AddSprite('fbody'..(99999 * noteid + j), 'notefbody.png')
                    notefbody.Beat = Editor:BeatAdd(Editor:GetNoteBeat(noteid, 1), Editor:GetNoteSlideBodyBeat(noteid, 0))
                    notefbody.X = (Editor:GetNoteX(noteid) + Editor:GetNoteSlideBodyX(noteid, 0) / 2) * 100 / 255
                    notefbody.Width = math.abs(Editor:GetNoteSlideBodyX(noteid, 0)) * 115 / 255
                    notefbody.HeightBeat = {beat=0, numor=1, denom=2}
                else
                    notebody = Editor:AddSprite('body'..(99999 * noteid + j), 'notebody.png')
                    half = beataverage(Editor:GetNoteSlideBodyBeat(noteid, j), Editor:GetNoteSlideBodyBeat(noteid, j - 1))
                    notebody.Beat = Editor:BeatAdd(Editor:GetNoteBeat(noteid, 1), half)
                    notebody.X = (Editor:GetNoteSlideBodyX(noteid, j - 1) + Editor:GetNoteX(noteid)) * 100 / 255
                    notebody.Width = 200 / rm_column
                    notebody.HeightBeat = Editor:BeatMinus(Editor:GetNoteSlideBodyBeat(noteid, j), Editor:GetNoteSlideBodyBeat(noteid, j - 1))
                    notefbody = Editor:AddSprite('fbody'..(99999 * noteid + j), 'notefbody.png')
                    notefbody.Beat = Editor:BeatAdd(Editor:GetNoteBeat(noteid, 1), Editor:GetNoteSlideBodyBeat(noteid, j))
                    notefbody.X = (Editor:GetNoteX(noteid) + (Editor:GetNoteSlideBodyX(noteid, j - 1) + Editor:GetNoteSlideBodyX(noteid, j)) / 2) * 100 / 255
                    notefbody.Width = math.abs(Editor:GetNoteSlideBodyX(noteid, j) - Editor:GetNoteSlideBodyX(noteid, j - 1)) * 115 / 255
                    notefbody.HeightBeat = {beat=0, numor=1, denom=2}
                end
                table.insert(bodytable, 99999 * noteid + j)
                table.insert(fbodytable, 99999 * noteid + j)
            end
            if bodycount == 1 then
                if Editor:GetNoteSlideBodyX(noteid, 0) ~= 0 then
                    if Editor:GetNoteSlideBodyX(noteid, 0) > 0 then
                        tailtri = Editor:AddSprite('tailtri'..noteid, 'tailsr.png')
                    else
                        tailtri = Editor:AddSprite('tailtri'..noteid, 'tailsl.png')
                    end
                    tailtri.Beat = Editor:BeatAdd(Editor:GetNoteBeat(noteid, 1), Editor:GetNoteSlideBodyBeat(noteid, 0))
                    tailtri.X = (Editor:GetNoteX(noteid) + Editor:GetNoteSlideBodyX(noteid, 0)) * 100 / 255
                    tailtri.Width = 40 / rm_column
                    tailtri.HeightBeat = {beat=0, numor=1, denom=4}
                    table.insert(tailtritable, noteid)
                else
                    tail = Editor:AddSprite('tail'..noteid, 'tail.png')
                    tail.Beat = Editor:BeatAdd(Editor:GetNoteBeat(noteid, 1), Editor:GetNoteSlideBodyBeat(noteid, 0))
                    tail.X = (Editor:GetNoteX(noteid) + Editor:GetNoteSlideBodyX(noteid, 0)) * 100 / 255
                    tail.Width = 75 / rm_column
                    tail.HeightBeat = {beat=0, numor=1, denom=4}
                    table.insert(tailtable, noteid)
                end
            else
                if Editor:GetNoteSlideBodyX(noteid, bodycount - 1) ~= Editor:GetNoteSlideBodyX(noteid, bodycount - 2) then
                    if Editor:GetNoteSlideBodyX(noteid, bodycount - 1) > Editor:GetNoteSlideBodyX(noteid, bodycount - 2) then
                        tailtri = Editor:AddSprite('tailtri'..noteid, 'tailsr.png')
                    else
                        tailtri = Editor:AddSprite('tailtri'..noteid, 'tailsl.png')
                    end
                    tailtri.Beat = Editor:BeatAdd(Editor:GetNoteBeat(noteid, 1), Editor:GetNoteSlideBodyBeat(noteid, bodycount - 1))
                    tailtri.X = (Editor:GetNoteX(noteid) + Editor:GetNoteSlideBodyX(noteid, bodycount - 1)) * 100 / 255
                    tailtri.Width = 40 / rm_column
                    tailtri.HeightBeat = {beat=0, numor=1, denom=4}
                    table.insert(tailtritable, noteid)
                else
                    tail = Editor:AddSprite('tail'..noteid, 'tail.png')
                    tail.Beat = Editor:BeatAdd(Editor:GetNoteBeat(noteid, 1), Editor:GetNoteSlideBodyBeat(noteid, bodycount - 1))
                    tail.X = (Editor:GetNoteX(noteid) + Editor:GetNoteSlideBodyX(noteid, bodycount - 1)) * 100 / 255
                    tail.Width = 75 / rm_column
                    tail.HeightBeat = {beat=0, numor=1, denom=4}
                    table.insert(tailtable, noteid)
                end
            end
        end
        table.insert(pictable, noteid)
    else
        
    end
end

function removeitem(tb, value)
    for i = #tb, 1, -1 do
        if tb[i] == tonumber(value) then
            table.remove(tb, i)
            return
        end
    end
end

function setglobalkey()
    local item = ''
    if #pictable > 0 then
        for i = 1, #pictable do
            if i == 1 then
                item = item..pictable[i]
            else
                item = item..'|'..pictable[i]
            end
        end
    end
    Editor:WriteData('pic', 123, item)
    item = ''
    if #bodytable > 0 then
        for i = 1, #bodytable do
            if i == 1 then
                item = item..bodytable[i]
            else
                item = item..'|'..bodytable[i]
            end
        end
    end
    Editor:WriteData('body', 123, item)
    item = ''
    if #fbodytable > 0 then
        for i = 1, #fbodytable do
            if i == 1 then
                item = item..fbodytable[i]
            else
                item = item..'|'..fbodytable[i]
            end
        end
    end
    Editor:WriteData('fbody', 123, item)
    item = ''
    if #tailtable > 0 then
        for i = 1, #tailtable do
            if i == 1 then
                item = item..tailtable[i]
            else
                item = item..'|'..tailtable[i]
            end
        end
    end
    Editor:WriteData('tail', 123, item)
    item = ''
    if #tailtritable > 0 then
        for i = 1, #tailtritable do
            if i == 1 then
                item = item..tailtritable[i]
            else
                item = item..'|'..tailtritable[i]
            end
        end
    end
    Editor:WriteData('tailtri', 123, item)
    item = ''
    if #multiselect > 0 then
        for i = 1, #multiselect do
            if i == 1 then
                item = item..multiselect[i]
            else
                item = item..'|'..multiselect[i]
            end
        end
    end
    Editor:WriteData('multiselect', 123, item)
    Editor:WriteData('selected', 123, selectnote)
    Editor:WriteData('startnote', 123, startnote)
end

function getglobalkey()
    pictable = split(Editor:ReadData('pic', 123), '|')
    bodytable = split(Editor:ReadData('body', 123), '|')
    fbodytable = split(Editor:ReadData('fbody', 123), '|')
    tailtable = split(Editor:ReadData('tail', 123), '|')
    tailtritable = split(Editor:ReadData('tailtri', 123), '|')
    multiselect = split(Editor:ReadData('multiselect', 123), '|')
    startnote = tonumber(Editor:ReadData('startnote', 123))
    selectnote = tonumber(Editor:ReadData('selected', 123))
end